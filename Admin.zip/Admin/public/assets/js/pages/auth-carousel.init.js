/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**************************************************!*\
  !*** ./resources/js/pages/auth-carousel.init.js ***!
  \**************************************************/
/*
Template Name: Minible - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: auth-carousel init js
*/

$(document).ready(function () {
  $('#auth-carousel').owlCarousel({
    loop: false,
    margin: 10,
    nav: false,
    items: 1
  });
});
/******/ })()
;